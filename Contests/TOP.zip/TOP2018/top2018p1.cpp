// author: Rayan Labidi
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
 
int main(){
    ll n;
    cin>>n;
    ll tab[n];
    ll res=1;
    for(int i=0;i<n;i++){
        cin>>tab[i];
    }
    int indstop=n-1;
    for(int i=0;i<n;i++){
        if(tab[i]==1){
            indstop=i;
            break;
        }
    }
    for(int i=indstop;i>=0;i--){
        res=pow(tab[i],res);
        if(res>=2147483648||res==0||res<-2147483648) return cout << "too large",0;
    }
    cout << res;
}