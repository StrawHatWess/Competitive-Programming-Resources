#include<bits/stdc++.h>
#define MAXN 1005
using namespace std;

int T,N,Q;

vector<int> adj[MAXN];

int dfn[MAXN], timer = 0;
int dep[MAXN];
int anc[MAXN][21];

void dfs(int u){
    dfn[u] = ++timer;
    
    for(int j=1;j<=20;j++){
        anc[u][j] = anc[anc[u][j-1]][j-1];
    }
    
    int v;
    for(int k=0;k<adj[u].size();k++){
        v = adj[u][k];
        if(dfn[v]) continue;
        dep[v] = dep[u] + 1;
        anc[v][0] = u;
        dfs(v);	
    }
}

int lca(int u, int v){
    if(dep[u] < dep[v]) swap(u,v);
    for(int j=20;j>=0;j--){
        if(dep[anc[u][j]] >= dep[v]){
            u = anc[u][j];
        }
    }
    if(u == v) return u;
    for(int j=20;j>=0;j--){
        if(anc[u][j] != anc[v][j]){
            u = anc[u][j];
            v = anc[v][j];
        }
    }
    return anc[u][0];
} 


int main(){
	scanf("%d", &T);
	
	for(int t=1;t<=T;t++){
		scanf("%d", &N);
		
		//clear
		timer = 0;
		memset(dfn, 0, sizeof(dfn));
		for(int i=1;i<=N;i++){
			adj[i].clear();
		}
		
		int m,u,v;
		for(u=1;u<=N;u++){
			scanf("%d", &m);
			while(m--){
				scanf("%d", &v);
				adj[u].push_back(v);
			}
		}
		
		dep[1] = 1;
		dfs(1);
		
		printf("Case %d:\n", t);
		scanf("%d", &Q);
		while(Q--){
			scanf("%d%d", &u, &v);
    		printf("%d\n", lca(u,v));
		}
	}


    return 0;
}
