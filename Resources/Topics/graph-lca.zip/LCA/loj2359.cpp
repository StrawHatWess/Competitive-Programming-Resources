#include<bits/stdc++.h>
#define MAXN 600005
using namespace std;

int N,M;

int w[MAXN];
int ans[MAXN];
vector<int> adj[MAXN];

int val[2][MAXN];
vector<int> adjAdd[2][MAXN], adjDel[2][MAXN];
int dep[MAXN], anc[MAXN][21];

void dfs0(int u){
	//
	for(int j=1;j<=20;j++){
		anc[u][j] = anc[anc[u][j-1]][j-1];
	}
	
	int v;
	for(int k=0;k<adj[u].size();k++){
		v = adj[u][k];
		if(v == anc[u][0]) continue;
		
		dep[v] = dep[u] + 1;
		anc[v][0] = u;
		dfs0(v);
	}
}

int lca(int u, int v){
	if(dep[u] < dep[v]) swap(u, v);
	for(int j=20;j>=0;j--){
		if(dep[anc[u][j]] >= dep[v]){
			u = anc[u][j];
		}
	}
	if(u==v) return u;
	
	for(int j=20;j>=0;j--){
		if(anc[u][j] != anc[v][j]){
			u = anc[u][j];
			v = anc[v][j];
		}
	}
	return anc[u][0];
}


void dfs1(int u){
	//A
	int ans0 = val[0][dep[u] + w[u]] + val[1][w[u] - dep[u] + N];
	for(int k=0;k<adjAdd[0][u].size();k++){
		val[0][adjAdd[0][u][k]]++;
	}
	for(int k=0;k<adjAdd[1][u].size();k++){
		val[1][adjAdd[1][u][k]]++;
	}
	//B
	for(int k=0;k<adj[u].size();k++){
		int v = adj[u][k];
		if(v == anc[u][0]) continue;
		
		dfs1(v);
	}
	
	for(int k=0;k<adjDel[0][u].size();k++){
		val[0][adjDel[0][u][k]]--;
	}
	for(int k=0;k<adjDel[1][u].size();k++){
		val[1][adjDel[1][u][k]]--;
	}
	
	ans[u] = val[0][dep[u] + w[u]] + val[1][w[u] - dep[u] + N] - ans0;
}

int main(){
	ios::sync_with_stdio(0);
	
	cin>>N>>M;
	
	int u,v;
	for(int i=1;i<N;i++){
		cin>>u>>v;
		adj[u].push_back(v);
		adj[v].push_back(u);
	}
	
	for(int i=1;i<=N;i++){
		cin>>w[i];
	}
	
	dep[1] = 1;
	dfs0(1);
	
	int s,t;
	for(int i=1;i<=M;i++){
		cin>>s>>t;
		
		int z = lca(s,t);
		
		adjAdd[0][s].push_back(dep[s]);
		adjDel[0][z].push_back(dep[s]);
		
		adjAdd[1][t].push_back(dep[s] - 2*dep[z] + N);
		adjDel[1][anc[z][0]].push_back(dep[s] - 2*dep[z] + N);
	}
	
	dfs1(1);
	
	for(int i=1;i<=N;i++){
		cout<<ans[i]<<" ";
	}
	
	return 0;
}

