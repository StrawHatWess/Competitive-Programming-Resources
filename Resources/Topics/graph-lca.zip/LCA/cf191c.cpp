#include<bits/stdc++.h>
#define MAXN 200005
using namespace std;

int T,N,Q;

struct edge{
	int v,id;
	edge(int v=0, int id=0):v(v), id(id){}
};
vector<edge> adj[MAXN];

int dfn[MAXN], timer = 0;
int dep[MAXN];
int anc[MAXN][21];

void dfs1(int u){
    dfn[u] = ++timer;
    
    for(int j=1;j<=20;j++){
        anc[u][j] = anc[anc[u][j-1]][j-1];
    }
    
    int v;
    for(int k=0;k<adj[u].size();k++){
        v = adj[u][k].v;
        if(dfn[v]) continue;
        dep[v] = dep[u] + 1;
        anc[v][0] = u;
        dfs1(v);	
    }
}

int lca(int u, int v){
    if(dep[u] < dep[v]) swap(u,v);
    for(int j=20;j>=0;j--){
        if(dep[anc[u][j]] >= dep[v]){
            u = anc[u][j];
        }
    }
    if(u == v) return u;
    for(int j=20;j>=0;j--){
        if(anc[u][j] != anc[v][j]){
            u = anc[u][j];
            v = anc[v][j];
        }
    }
    return anc[u][0];
} 

int d[MAXN], ans[MAXN];
void dfs2(int u){
	
	int v,id;
    for(int k=0;k<adj[u].size();k++){
        v = adj[u][k].v;
        id = adj[u][k].id;
        if(v == anc[u][0]) continue;
        dfs2(v);
		d[u] += d[v];
		ans[id] = d[v];	
    }
}


int main(){

	
	scanf("%d", &N);
	
	int u,v,z;
	for(int i=1;i<N;i++){
		scanf("%d%d", &u, &v);

		adj[u].push_back(edge(v,i));
		adj[v].push_back(edge(u,i));
	}
	
	dep[1] = 1;
	dfs1(1);

	scanf("%d", &Q);
	while(Q--){
		scanf("%d%d", &u, &v);
		z = lca(u,v);
		++d[u];
		++d[v];
		--d[z];
		--d[z];
	}
	
	dfs2(1);
	
	for(int i=1;i<N;i++){
		printf("%d ", ans[i]);
	}

    return 0;
}
